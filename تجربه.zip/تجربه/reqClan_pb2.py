# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════════════════════╗
# ║                                                                      ║
# ║   ██████╗  █████╗ ███████╗██╗███╗   ██╗                              ║
# ║   ██╔══██╗██╔══██╗██╔════╝██║████╗  ██║                              ║
# ║   ██████╔╝███████║█████╗  ██║██╔██╗ ██║                              ║
# ║   ██╔══██╗██╔══██║██╔══╝  ██║██║╚██╗██║                              ║
# ║   ██║  ██║██║  ██║██║     ██║██║ ╚████║                              ║
# ║   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═══╝                              ║
# ║                                                                      ║
# ║                  ★   R A F I N   T x T   ★                           ║
# ║                  P R E M I U M   E D I T I O N                       ║
# ║                                                                      ║
# ╚══════════════════════════════════════════════════════════════════════╝
#
#  ┌──────────────────────────────────────────────────────────────────┐
#  │  Project      :  reqClan                                         │
#  │  Module       :  reqClan_pb2                                     │
#  │  Author       :  RAFIN TxT                                       │
#  │  Protobuf Ver :  6.30.0                                          │
#  │  Language     :  Python                                          │
#  │  Status       :  Auto-generated — DO NOT EDIT                    │
#  └──────────────────────────────────────────────────────────────────┘
#
#  © RAFIN TxT — All rights reserved.
#
"""RAFIN TxT — reqClan Protocol Buffer Module.

Premium Edition — auto-generated protocol buffer code.
Source: reqClan.proto
"""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC,
    6,
    30,
    0,
    '',
    'reqClan.proto'
)
# @@protoc_insertion_point(imports)

_sym_db = _symbol_database.Default()




DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\rreqClan.proto\"\x1c\n\tMyMessage\x12\x0f\n\x07\x66ield_1\x18\x01 \x01(\x03\x62\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'reqClan_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
  DESCRIPTOR._loaded_options = None
  _globals['_MYMESSAGE']._serialized_start=17
  _globals['_MYMESSAGE']._serialized_end=45
# @@protoc_insertion_point(module_scope)

# ╔══════════════════════════════════════════════════════════════════════╗
# ║   End of file  —  RAFIN TxT  —  Premium Edition                      ║
# ╚══════════════════════════════════════════════════════════════════════╝